
package com.example.messageconvertor.controller;

import com.example.messageconvertor.dto.MessageRequest;
import com.example.messageconvertor.service.MessageTransformationService;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/message")
@RequiredArgsConstructor
public class MessageConvertorController {

    private final MessageTransformationService transformationService;

    @PostMapping("/transform")
    public ResponseEntity<List<JsonNode>> transform(
            @RequestBody MessageRequest request) {

        return ResponseEntity.ok(
                transformationService.transform(request)
        );
    }
}
