
package com.example.messageconvertor.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "MESSAGE_CONVERTOR_RULE")
@Getter
@Setter
public class MessageConvertorRule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "RULE_ID")
    private Long ruleId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SERVICE_ID")
    private MessageConvertorMaster master;

    @Column(name = "SOURCE_JSON_PATH")
    private String sourceJsonPath;

    @Column(name = "TARGET_JSON_PATH")
    private String targetJsonPath;

    @Lob
    @Column(name = "TRANSFORMATION_EXPRESSION")
    private String transformationExpression;
}
