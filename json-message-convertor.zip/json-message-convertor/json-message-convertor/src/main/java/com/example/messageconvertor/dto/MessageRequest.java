
package com.example.messageconvertor.dto;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.Getter;
import lombok.Setter;

import java.util.Map;

@Getter
@Setter
public class MessageRequest {

    private Map<String, String> requestHeaders;

    private JsonNode requestPayload;
}
