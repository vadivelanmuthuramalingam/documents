
package com.example.messageconvertor.service;

import com.example.messageconvertor.dto.MessageRequest;
import com.example.messageconvertor.entity.MessageConvertorMaster;
import com.example.messageconvertor.repository.MessageConvertorMasterRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class MessageTransformationService {

    private final ObjectMapper mapper;
    private final MessageConvertorMasterRepository repository;

    public List<JsonNode> transform(MessageRequest request) {

        JsonNode payload = request.getRequestPayload();

        MessageConvertorMaster config =
                repository
                        .findByDomainNameAndVersionAndSubDomainNameAndStatus(
                                payload.get("domainName").asText(),
                                payload.get("version").asText(),
                                payload.get("subDomainName").asText(),
                                "Y")
                        .orElseThrow(() ->
                                new RuntimeException("Configuration not found"));

        return switch (config.getServiceType()) {
            case MANY_TO_MANY -> processManyToMany(request, payload);
            case ONE_TO_MANY -> processOneToMany(request, payload);
        };
    }

    private List<JsonNode> processManyToMany(
            MessageRequest request,
            JsonNode payload) {

        ArrayNode transactions =
                (ArrayNode) payload.get("transactions");

        List<JsonNode> responses = new ArrayList<>();

        for (JsonNode transaction : transactions) {
            responses.add(buildMessage(request, payload, transaction));
        }

        return responses;
    }

    private List<JsonNode> processOneToMany(
            MessageRequest request,
            JsonNode payload) {

        Integer noOfTransactions =
                payload.get("noOfTransaction").asInt();

        JsonNode transaction =
                payload.get("transaction");

        List<JsonNode> responses = new ArrayList<>();

        for (int i = 1; i <= noOfTransactions; i++) {

            ObjectNode cloned = transaction.deepCopy();

            cloned.put("transactionId",
                    String.format("%03d", i));

            responses.add(
                    buildMessage(request, payload, cloned)
            );
        }

        return responses;
    }

    private ObjectNode buildMessage(
            MessageRequest request,
            JsonNode payload,
            JsonNode transaction) {

        ObjectNode root = mapper.createObjectNode();

        ObjectNode headers = mapper.createObjectNode();

        headers.put("api-sys-id",
                UUID.randomUUID().toString());

        headers.put("req-sys-id",
                UUID.randomUUID().toString());

        headers.put("country",
                request.getRequestHeaders().get("country"));

        headers.put("region",
                request.getRequestHeaders().get("region"));

        headers.put("bulk-api-sys-id",
                request.getRequestHeaders().get("api-sys-id"));

        headers.put("bulk-req-sys-id",
                request.getRequestHeaders().get("req-sys-id"));

        headers.put("bulkTranId",
                payload.get("bulkTranId").asText());

        root.set("requestHeaders", headers);

        ObjectNode payloadNode =
                (ObjectNode) transaction.deepCopy();

        JsonNode commonParams =
                payload.get("commonParams");

        if (commonParams != null) {
            merge(payloadNode, commonParams);
        }

        root.set("payload", payloadNode);

        return root;
    }

    private void merge(
            ObjectNode target,
            JsonNode source) {

        source.fields().forEachRemaining(entry -> {

            JsonNode existing =
                    target.get(entry.getKey());

            if (existing != null
                    && existing.isObject()
                    && entry.getValue().isObject()) {

                merge((ObjectNode) existing,
                        entry.getValue());

            } else {

                target.set(
                        entry.getKey(),
                        entry.getValue());
            }
        });
    }
}
