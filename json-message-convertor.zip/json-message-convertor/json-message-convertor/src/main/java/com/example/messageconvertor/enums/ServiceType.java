
package com.example.messageconvertor.enums;

public enum ServiceType {
    ONE_TO_MANY,
    MANY_TO_MANY
}
