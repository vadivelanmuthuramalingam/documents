
package com.example.messageconvertor.repository;

import com.example.messageconvertor.entity.MessageConvertorMaster;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface MessageConvertorMasterRepository
        extends JpaRepository<MessageConvertorMaster, Long> {

    Optional<MessageConvertorMaster>
    findByDomainNameAndVersionAndSubDomainNameAndStatus(
            String domainName,
            String version,
            String subDomainName,
            String status
    );
}
