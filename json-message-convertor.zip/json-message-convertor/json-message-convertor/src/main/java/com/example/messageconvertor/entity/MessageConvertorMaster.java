
package com.example.messageconvertor.entity;

import com.example.messageconvertor.enums.ServiceType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Entity
@Table(name = "MESSAGE_CONVERTOR_MASTER")
@Getter
@Setter
public class MessageConvertorMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SERVICE_ID")
    private Long serviceId;

    @Column(name = "DOMAIN_NAME")
    private String domainName;

    @Column(name = "VERSION")
    private String version;

    @Column(name = "SUB_DOMAIN_NAME")
    private String subDomainName;

    @Enumerated(EnumType.STRING)
    @Column(name = "SERVICE_TYPE")
    private ServiceType serviceType;

    @Column(name = "STATUS")
    private String status;

    @OneToMany(mappedBy = "master", cascade = CascadeType.ALL)
    private List<MessageConvertorRule> rules;
}
