
package com.example.messageconvertor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MessageConvertorApplication {

    public static void main(String[] args) {
        SpringApplication.run(MessageConvertorApplication.class, args);
    }
}
