
package com.example.transform.repository;

import com.example.transform.entity.TransformationMapping;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TransformationMappingRepository extends JpaRepository<TransformationMapping, Long> {
    List<TransformationMapping> findByTransformationId(Long transformationId);
}
