
package com.example.transform.service;

import com.example.transform.engine.TransformationEngine;
import com.example.transform.entity.TransformationMapping;
import com.example.transform.entity.TransformationMaster;
import com.example.transform.repository.TransformationMappingRepository;
import com.example.transform.repository.TransformationMasterRepository;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TransformationService {

    private final TransformationMasterRepository masterRepository;
    private final TransformationMappingRepository mappingRepository;
    private final TransformationEngine transformationEngine;

    public JsonNode transform(String transformationName,
                              String payload) throws Exception {

        TransformationMaster master =
                masterRepository.findByTransformationName(transformationName)
                        .orElseThrow(() ->
                                new RuntimeException("Transformation not found"));

        List<TransformationMapping> mappings =
                mappingRepository.findByTransformationId(master.getId());

        return transformationEngine.transform(payload, mappings);
    }
}
