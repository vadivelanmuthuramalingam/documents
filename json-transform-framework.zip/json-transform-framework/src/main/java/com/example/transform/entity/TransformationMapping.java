
package com.example.transform.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "TRANSFORMATION_MAPPING")
@Data
public class TransformationMapping {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long transformationId;
    private String sourcePath;
    private String targetPath;
    private String dataType;
    private String defaultValue;
}
