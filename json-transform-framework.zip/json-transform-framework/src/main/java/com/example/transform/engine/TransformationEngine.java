
package com.example.transform.engine;

import com.example.transform.entity.TransformationMapping;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jayway.jsonpath.JsonPath;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class TransformationEngine {

    private final ObjectMapper mapper = new ObjectMapper();

    public JsonNode transform(String input,
                              List<TransformationMapping> mappings) throws Exception {

        Object document = com.jayway.jsonpath.Configuration.defaultConfiguration()
                .jsonProvider()
                .parse(input);

        ObjectNode output = mapper.createObjectNode();

        for (TransformationMapping mapping : mappings) {

            Object value;

            try {
                value = JsonPath.read(document, mapping.getSourcePath());
            } catch (Exception ex) {
                value = mapping.getDefaultValue();
            }

            build(output, mapping.getTargetPath(), value);
        }

        return output;
    }

    private void build(ObjectNode output,
                       String targetPath,
                       Object value) {

        String cleaned = targetPath.replace("$.","");
        String[] parts = cleaned.split("\\.");

        ObjectNode current = output;

        for(int i=0;i<parts.length-1;i++) {
            if(!current.has(parts[i])) {
                current.putObject(parts[i]);
            }
            current = (ObjectNode) current.get(parts[i]);
        }

        current.putPOJO(parts[parts.length - 1], value);
    }
}
