
package com.example.transform.controller;

import com.example.transform.dto.TransformationRequest;
import com.example.transform.service.TransformationService;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/transform")
@RequiredArgsConstructor
public class TransformationController {

    private final TransformationService transformationService;

    @PostMapping
    public JsonNode transform(@RequestBody TransformationRequest request)
            throws Exception {

        return transformationService.transform(
                request.getTransformationName(),
                request.getPayload());
    }
}
