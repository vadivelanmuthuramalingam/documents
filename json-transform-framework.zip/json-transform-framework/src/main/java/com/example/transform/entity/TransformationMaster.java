
package com.example.transform.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "MASTER_TRANSFORMATION")
@Data
public class TransformationMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String transformationName;
    private String sourceType;
    private String targetType;
    private String version;
    private String status;
}
