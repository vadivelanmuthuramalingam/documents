
package com.example.transform.repository;

import com.example.transform.entity.TransformationMaster;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface TransformationMasterRepository extends JpaRepository<TransformationMaster, Long> {
    Optional<TransformationMaster> findByTransformationName(String transformationName);
}
