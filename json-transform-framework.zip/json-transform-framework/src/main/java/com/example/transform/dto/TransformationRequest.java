
package com.example.transform.dto;

import lombok.Data;

@Data
public class TransformationRequest {
    private String transformationName;
    private String payload;
}
