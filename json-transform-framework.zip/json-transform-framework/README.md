
# JSON Transformation Framework

## Features
- Dynamic JSON to JSON transformation
- DB-driven mapping
- JSONPath support
- One-to-One mapping
- Nested object building
- Spring Boot 3.3.5
- Oracle support

## Run

mvn clean install
mvn spring-boot:run

## API

POST /api/transform

Sample Request:

{
  "transformationName": "CUSTOMER_TRANSFORM",
  "payload": "{\"customer\":{\"name\":\"John\",\"accounts\":[{\"balance\":100}]}}"
}
