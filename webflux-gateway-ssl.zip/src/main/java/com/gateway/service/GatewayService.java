
package com.gateway.service;

import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public class GatewayService {

 private final WebClientFactory factory;

 public GatewayService(WebClientFactory factory) {
   this.factory = factory;
 }

 public Mono<String> callService(String client, String payload) {

   return factory.getClient(client)
           .post()
           .bodyValue(payload)
           .retrieve()
           .bodyToMono(String.class);
 }
}
