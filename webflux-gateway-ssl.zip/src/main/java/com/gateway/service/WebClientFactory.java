
package com.gateway.service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.gateway.config.GatewayProperties;

@Service
public class WebClientFactory {

 private final Map<String, WebClient> clients = new ConcurrentHashMap<>();

 public WebClientFactory(WebClient baseClient,
                         GatewayProperties properties) {

   for (GatewayProperties.Client c : properties.getClients()) {

     WebClient client = baseClient.mutate()
             .baseUrl(c.getUrl())
             .build();

     clients.put(c.getName(), client);
   }
 }

 public WebClient getClient(String name) {
   return clients.get(name);
 }
}
