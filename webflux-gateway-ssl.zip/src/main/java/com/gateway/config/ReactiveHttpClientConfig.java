
package com.gateway.config;

import io.netty.handler.ssl.SslContext;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;

import java.time.Duration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class ReactiveHttpClientConfig {

 @Bean
 public ConnectionProvider connectionProvider() {

   return ConnectionProvider.builder("gateway-pool")
           .maxConnections(2000)
           .pendingAcquireMaxCount(5000)
           .maxIdleTime(Duration.ofSeconds(30))
           .maxLifeTime(Duration.ofMinutes(5))
           .evictInBackground(Duration.ofSeconds(30))
           .build();
 }

 @Bean
 public HttpClient httpClient(ConnectionProvider provider,
                              SslContext sslContext) {

   return HttpClient.create(provider)
           .secure(ssl -> ssl.sslContext(sslContext))
           .compress(true)
           .keepAlive(true)
           .responseTimeout(Duration.ofSeconds(5));
 }

 @Bean
 public WebClient webClient(HttpClient httpClient) {

   return WebClient.builder()
           .clientConnector(new ReactorClientHttpConnector(httpClient))
           .build();
 }
}
