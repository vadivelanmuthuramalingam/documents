
package com.gateway.config;

import java.util.List;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "gateway")
public class GatewayProperties {

 private List<Client> clients;

 public List<Client> getClients() { return clients; }
 public void setClients(List<Client> clients) { this.clients = clients; }

 public static class Client {

   private String name;
   private String url;
   private int socketTimeout;
   private int connectionTimeout;

   public String getName() { return name; }
   public void setName(String name) { this.name = name; }

   public String getUrl() { return url; }
   public void setUrl(String url) { this.url = url; }

   public int getSocketTimeout() { return socketTimeout; }
   public void setSocketTimeout(int socketTimeout) { this.socketTimeout = socketTimeout; }

   public int getConnectionTimeout() { return connectionTimeout; }
   public void setConnectionTimeout(int connectionTimeout) { this.connectionTimeout = connectionTimeout; }
 }
}
