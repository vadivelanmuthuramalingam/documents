
package com.gateway.config;

import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import javax.net.ssl.TrustManagerFactory;
import java.io.InputStream;
import java.security.KeyStore;

@Configuration
public class SSLConfiguration {

 @Bean
 public SslContext sslContext() throws Exception {

   KeyStore trustStore = KeyStore.getInstance("JKS");

   try (InputStream is =
       new ClassPathResource("truststore.jks").getInputStream()) {

     trustStore.load(is, "changeit".toCharArray());
   }

   TrustManagerFactory tmf =
       TrustManagerFactory.getInstance(
           TrustManagerFactory.getDefaultAlgorithm());

   tmf.init(trustStore);

   return SslContextBuilder.forClient()
           .trustManager(tmf)
           .build();
 }
}
