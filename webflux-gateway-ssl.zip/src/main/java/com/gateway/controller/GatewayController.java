
package com.gateway.controller;

import org.springframework.web.bind.annotation.*;

import com.gateway.service.GatewayService;

import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/gateway")
public class GatewayController {

 private final GatewayService service;

 public GatewayController(GatewayService service) {
   this.service = service;
 }

 @PostMapping("/{client}")
 public Mono<String> forwardRequest(
         @PathVariable String client,
         @RequestBody String payload) {

   return service.callService(client, payload);
 }
}
