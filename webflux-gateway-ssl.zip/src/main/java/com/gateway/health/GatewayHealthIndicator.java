
package com.gateway.health;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.ReactiveHealthIndicator;
import org.springframework.stereotype.Component;

import com.gateway.config.GatewayProperties;
import com.gateway.service.WebClientFactory;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
public class GatewayHealthIndicator implements ReactiveHealthIndicator {

 private final GatewayProperties properties;
 private final WebClientFactory factory;

 public GatewayHealthIndicator(GatewayProperties properties,
                               WebClientFactory factory) {
   this.properties = properties;
   this.factory = factory;
 }

 @Override
 public Mono<Health> health() {

   List<Mono<Boolean>> checks = new ArrayList<>();

   for (GatewayProperties.Client c : properties.getClients()) {

     Mono<Boolean> check = factory.getClient(c.getName())
             .get()
             .retrieve()
             .bodyToMono(String.class)
             .map(r -> true)
             .onErrorReturn(false);

     checks.add(check);
   }

   return Flux.merge(checks)
           .all(v -> v)
           .map(v -> v ? Health.up().build()
                       : Health.down().build());
 }
}
