
package com.gateway.warmup;

import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import com.gateway.service.WebClientFactory;

@Component
public class ConnectionWarmup {

 private final WebClientFactory factory;

 public ConnectionWarmup(WebClientFactory factory) {
   this.factory = factory;
 }

 @EventListener(ApplicationReadyEvent.class)
 public void warmConnections() {

   factory.getClient("service1")
           .get()
           .retrieve()
           .bodyToMono(String.class)
           .subscribe();
 }
}
