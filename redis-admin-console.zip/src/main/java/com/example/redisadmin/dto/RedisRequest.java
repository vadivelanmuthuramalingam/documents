
package com.example.redisadmin.dto;
public class RedisRequest {
 private String command;
 public String getCommand(){return command;}
 public void setCommand(String command){this.command=command;}
}
