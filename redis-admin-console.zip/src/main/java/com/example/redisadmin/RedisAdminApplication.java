
package com.example.redisadmin;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class RedisAdminApplication {
 public static void main(String[] args){
   SpringApplication.run(RedisAdminApplication.class,args);
 }
}
