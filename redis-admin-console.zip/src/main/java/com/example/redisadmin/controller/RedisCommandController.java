
package com.example.redisadmin.controller;
import com.example.redisadmin.dto.RedisRequest;
import com.example.redisadmin.service.RedisCommandService;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/api/redis")
public class RedisCommandController {
 private final RedisCommandService service;
 public RedisCommandController(RedisCommandService service){this.service=service;}
 @PostMapping("/execute")
 public Object execute(@RequestBody RedisRequest request){
   return service.execute(request);
 }
}
