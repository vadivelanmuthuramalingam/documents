
package com.example.redisadmin.service;
import com.example.redisadmin.dto.RedisRequest;
import org.springframework.stereotype.Service;
import redis.clients.jedis.Jedis;
import java.util.*;
@Service
public class RedisCommandService {
 private static final Set<String> ALLOWED=Set.of("GET","SET","DEL","TTL","EXISTS");
 public Object execute(RedisRequest request){
   String[] p=request.getCommand().split("\\s+");
   String cmd=p[0].toUpperCase();
   if(!ALLOWED.contains(cmd)) throw new RuntimeException("Command not allowed");
   try(Jedis jedis=new Jedis("localhost",6379)){
      return switch(cmd){
       case "GET" -> jedis.get(p[1]);
       case "SET" -> jedis.set(p[1],p[2]);
       case "DEL" -> jedis.del(p[1]);
       case "TTL" -> jedis.ttl(p[1]);
       case "EXISTS" -> jedis.exists(p[1]);
       default -> "Unsupported";
      };
   }
 }
}
