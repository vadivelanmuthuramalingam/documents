
package com.citi.multidb.service;

import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.*;
import java.util.*;

@Service
public class JdbcQueryService {

    private final DataSource dataSource;

    public JdbcQueryService(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public List<Map<String,Object>> executeQuery(String sql) throws Exception {

        List<Map<String,Object>> result = new ArrayList<>();

        try(Connection conn = dataSource.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql)) {

            ResultSetMetaData meta = rs.getMetaData();
            int count = meta.getColumnCount();

            while(rs.next()) {

                Map<String,Object> row = new HashMap<>();

                for(int i=1;i<=count;i++) {
                    row.put(meta.getColumnName(i), rs.getObject(i));
                }

                result.add(row);
            }
        }

        return result;
    }
}
