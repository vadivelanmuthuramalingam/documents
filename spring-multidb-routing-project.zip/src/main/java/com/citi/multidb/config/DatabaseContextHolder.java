
package com.citi.multidb.config;

public class DatabaseContextHolder {

    private static final ThreadLocal<String> context = new ThreadLocal<>();

    public static void setDatabase(String db) {
        context.set(db);
    }

    public static String getDatabase() {
        return context.get();
    }

    public static void clear() {
        context.remove();
    }
}
