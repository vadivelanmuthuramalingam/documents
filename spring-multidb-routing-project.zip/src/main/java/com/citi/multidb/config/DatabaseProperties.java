
package com.citi.multidb.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

@Configuration
@ConfigurationProperties(prefix = "app.databases")
public class DatabaseProperties {

    private Map<String, DbConfig> configs = new HashMap<>();

    public Map<String, DbConfig> getConfigs() {
        return configs;
    }

    public void setConfigs(Map<String, DbConfig> configs) {
        this.configs = configs;
    }
}
