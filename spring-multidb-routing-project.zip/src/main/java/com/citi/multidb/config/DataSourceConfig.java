
package com.citi.multidb.config;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

@Configuration
public class DataSourceConfig {

    @Bean
    public DataSource dataSource(DatabaseProperties properties) {

        Map<Object, Object> dataSources = new HashMap<>();

        properties.getConfigs().forEach((name, cfg) -> {

            HikariDataSource ds = new HikariDataSource();
            ds.setJdbcUrl(cfg.getUrl());
            ds.setUsername(cfg.getUsername());
            ds.setPassword(cfg.getPassword());
            ds.setDriverClassName(cfg.getDriver());

            ds.setMaximumPoolSize(20);
            ds.setMinimumIdle(5);
            ds.setIdleTimeout(30000);
            ds.setConnectionTimeout(20000);

            dataSources.put(name, ds);

        });

        DynamicRoutingDataSource routingDataSource = new DynamicRoutingDataSource();
        routingDataSource.setTargetDataSources(dataSources);
        routingDataSource.setDefaultTargetDataSource(dataSources.values().iterator().next());
        routingDataSource.afterPropertiesSet();

        return routingDataSource;
    }
}
