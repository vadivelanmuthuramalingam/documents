
package com.citi.multidb.controller;

import com.citi.multidb.config.DatabaseContextHolder;
import com.citi.multidb.service.JdbcQueryService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/query")
public class QueryController {

    private final JdbcQueryService service;

    public QueryController(JdbcQueryService service) {
        this.service = service;
    }

    @GetMapping
    public List<Map<String,Object>> runQuery(
            @RequestParam String db,
            @RequestParam String sql) throws Exception {

        try {

            DatabaseContextHolder.setDatabase(db);

            return service.executeQuery(sql);

        } finally {
            DatabaseContextHolder.clear();
        }
    }
}
