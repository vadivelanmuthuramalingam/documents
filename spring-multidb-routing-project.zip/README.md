
# Spring Boot Multi DB Routing (Thread Based)

Features:
- Multiple database connections
- HikariCP connection pooling
- ThreadLocal database routing
- JDBC Statement execution
- Dynamic DB selection

Run:

mvn clean install
mvn spring-boot:run

Example API:

http://localhost:8080/query?db=db1&sql=SELECT%20*%20FROM%20DUAL
